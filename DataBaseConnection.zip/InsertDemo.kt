package com.axis.database

import java.sql.DriverManager

fun main(args:Array<String>){
    val myURL="jdbc:mysql://localhost:3306/kotlindb"
    val connection=DriverManager.getConnection(myURL,"root","Komal@rock100")
    println("connection establish successfully !!!")


//   insert query -Create
    val stat = connection.createStatement()
    // insert user value and if want to insert more value just change(3,'Anmol')
    val res=stat.executeUpdate("insert into users values(1,'Anil')")
    if (res > 0) {
        println("successfully inserted record into users db !!!")
    } else {
        println("Insert Not sucessful")
    }
}




