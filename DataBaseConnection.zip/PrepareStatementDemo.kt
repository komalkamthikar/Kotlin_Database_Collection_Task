package com.axis.database

import java.sql.DriverManager
import java.sql.PreparedStatement

fun main(args:Array<String>) {
    val myURL = "jdbc:mysql://localhost:3306/kotlindb"
    val connection = DriverManager.getConnection(myURL, "root", "Komal@rock100")
    println("connection establish successfully !!!")

    val prestat=connection.prepareStatement("Insert into users values(?,?)")
    prestat.setInt(1,3)
    prestat.setString(2,"bro")
    val result=prestat.executeUpdate()
    if(result>0){
    println("Inserted")
    }
    else{
        println("Not Inserted")
    }
}