package com.axis.database

import java.sql.DriverManager


fun main(args:Array<String>) {
    val myURL = "jdbc:mysql://localhost:3306/kotlindb"
    val connection = DriverManager.getConnection(myURL, "root", "Komal@rock100")
    println("connection establish successfully !!!")

    //Update
    val stat = connection.createStatement()
    val update_res=stat.executeUpdate("update users set name = 'Rahul' where id = 1")
    if (update_res > 0) {
        println("successfully updated record in users db !!!")
    } else {
        println("Update Not successful")

    }
}

