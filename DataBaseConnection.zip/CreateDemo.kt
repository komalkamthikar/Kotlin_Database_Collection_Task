package com.axis.database

import java.sql.DriverManager

fun main(args:Array<String>) {
    val myURL = "jdbc:mysql://localhost:3306/kotlindb"
    val connection = DriverManager.getConnection(myURL, "root", "Komal@rock100")
    println("connection establish successfully !!!")

    val stmt = connection.createStatement()
    stmt.execute("create table product(id int,name varchar(45));")
    print("table created")
}

