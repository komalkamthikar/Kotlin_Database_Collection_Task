package com.axis.database

import java.sql.DriverManager

fun main(args:Array<String>) {
    val myURL = "jdbc:mysql://localhost:3306/kotlindb"
    val connection = DriverManager.getConnection(myURL, "root", "Komal@rock100")
    println("connection establish successfully !!!")
    //deletion
    val stmt = connection.createStatement()
    val delete_res = stmt.executeUpdate("delete from users where id = 1")
    if (delete_res > 0) {
        println("successfully deleted record in users db !!!")
        println("$delete_res rows deleted")
    } else {
        println("Deletion failed")
    }
}




